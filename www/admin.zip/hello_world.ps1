Write-Host("hello pandapache");
Start-Sleep -Seconds 10
Write-Host("Fin");
exit(0);